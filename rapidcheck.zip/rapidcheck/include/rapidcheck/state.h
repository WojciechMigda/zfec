#pragma once

#include <rapidcheck.h>

#include "rapidcheck/state/Command.h"
#include "rapidcheck/state/Commands.h"
#include "rapidcheck/state/State.h"
#include "rapidcheck/state/gen/Commands.h"
#include "rapidcheck/state/gen/ExecCommands.h"
